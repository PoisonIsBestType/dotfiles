# Sunrise GTK Themes
Gtk2 themes base on : [Adwaita](https://gitlab.gnome.org/GNOME/gnome-themes-extra/-/tree/gnome-3-22/themes) </br>
Gtk3 themes base on : [Adwaita](https://gitlab.gnome.org/GNOME/gtk/-/tree/gtk-3-24/gtk/theme/Adwaita) </br>
Gnome shell themes base on : [Gnome Shell themes ](https://gitlab.gnome.org/GNOME/gnome-shell/-/tree/gnome-3-38/data/theme)</br>
Xfwm4 themes base on : [Xfwm4 Default-theme](https://gitlab.xfce.org/Dridi/xfwm4/-/tree/master/themes/default)</br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1258305)</br></br>
SCREENSHOTS:</br>
![sunrisescreenshot](https://i.ibb.co/Wv9P1vK/sunrise-nautilus-screenshots.png "sunrise-nautilus-screenshot")</br></br>
![sunrisescreenshot](https://i.ibb.co/GRPyPFN/sunrise-widget-factory-screenshots.png "sunrise-widget-factory-screenshot")</br>
